/// <reference path="../pb_data/types.d.ts" />

// Auth was temporarily removed from the portal, so the browse collections need
// public read access for the workspace to be navigable without a session.
// Write rules stay restricted — without an auth session every create/update
// simply fails, which matches the read-only browsing experience for now.
migrate((app) => {
  const open = ["portal_clients", "portal_sops", "portal_versions", "portal_quizzes", "portal_resources"];
  for (const name of open) {
    const c = app.findCollectionByNameOrId(name);
    c.listRule = "";
    c.viewRule = "";
    app.save(c);
  }
}, (app) => {
  const restore = [
    ["portal_clients", "@request.auth.id != '' && (@request.auth.role = 'manager' || @request.auth.clients ?= id)"],
    ["portal_sops", "@request.auth.id != '' && (@request.auth.role = 'manager' || @request.auth.clients ?= client) && (status = 'Published' || @request.auth.role = 'manager' || @request.auth.role = 'trainer')"],
    ["portal_versions", "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))"],
    ["portal_quizzes", "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))"],
    ["portal_resources", "@request.auth.id != ''"],
  ];
  for (const [name, rule] of restore) {
    const c = app.findCollectionByNameOrId(name);
    c.listRule = rule;
    c.viewRule = rule;
    app.save(c);
  }
});
