/// <reference path="../pb_data/types.d.ts" />

// Auth was removed from the portal, so the SOP library needs to allow
// unauthenticated creates for the "Upload SOP" flow (select client + vertical,
// add a procedure). This opens create/update rules on portal_sops and
// portal_clients; read rules were already opened by 1790638000.
migrate((app) => {
  const open = ["portal_sops", "portal_clients"];
  for (const name of open) {
    const c = app.findCollectionByNameOrId(name);
    c.createRule = "";
    c.updateRule = "";
    app.save(c);
  }
}, (app) => {
  const restore = [
    ["portal_sops", "@request.auth.role = 'manager' || (@request.auth.role = 'trainer' && @request.auth.clients ?= @request.body.client && @request.body.status != 'Published')"],
    ["portal_clients", "@request.auth.role = 'manager'"],
  ];
  for (const [name, rule] of restore) {
    const c = app.findCollectionByNameOrId(name);
    c.createRule = rule;
    c.updateRule = rule;
    app.save(c);
  }
});
