/// <reference path="../pb_data/types.d.ts" />

// Auth was removed from the portal, so versioned document uploads need to
// work unauthenticated. Open the create rule on portal_versions; reads were
// already opened by 1790638000.
migrate((app) => {
  const c = app.findCollectionByNameOrId("portal_versions");
  c.createRule = "";
  app.save(c);
}, (app) => {
  const c = app.findCollectionByNameOrId("portal_versions");
  c.createRule = "@request.auth.role = 'manager' || @request.auth.role = 'trainer'";
  app.save(c);
});
