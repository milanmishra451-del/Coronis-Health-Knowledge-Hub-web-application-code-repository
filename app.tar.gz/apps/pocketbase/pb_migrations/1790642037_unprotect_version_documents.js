/// <reference path="../pb_data/types.d.ts" />

// The portal allows unauthenticated browsing, so protected file fields
// (which require an auth token via /api/files/token) return 401 for
// signed-out visitors. Make the SOP version document publicly readable
// so the download/open flow works without authentication.
migrate(
  (app) => {
    const collection = app.findCollectionByNameOrId("portal_versions");
    const field = collection.fields.getByName("document");
    field.protected = false;
    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId("portal_versions");
    const field = collection.fields.getByName("document");
    field.protected = true;
    app.save(collection);
  },
);
