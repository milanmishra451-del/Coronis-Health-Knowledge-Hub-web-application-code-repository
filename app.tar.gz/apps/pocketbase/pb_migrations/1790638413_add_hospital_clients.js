/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const clients = app.findCollectionByNameOrId("portal_clients");

    if (!clients.fields.getByName("serviceLine")) {
      clients.fields.add(
        new SelectField({
          name: "serviceLine",
          maxSelect: 1,
          values: ["Hospital", "Physician", "FQHC", "RHC", "Behavioral Health", "EMS", "Lab & Path"],
        }),
      );
      app.save(clients);
    }

    const hospitalClients = [
      "Meeker Memorial Hospital",
      "Barton Hospital",
      "Hiles & Dales Hospital",
      "Allendale Hospital",
      "Beacon Memorial Hospital",
    ];

    for (const name of hospitalClients) {
      try {
        app.findFirstRecordByData("portal_clients", "name", name);
      } catch (error) {
        if (!String(error).includes("no rows in result set")) throw error;
        const client = new Record(clients);
        client.load({ name, serviceLine: "Hospital" });
        app.save(client);
      }
    }
  },
  (app) => {
    const clients = app.findCollectionByNameOrId("portal_clients");
    for (const name of [
      "Meeker Memorial Hospital",
      "Barton Hospital",
      "Hiles & Dales Hospital",
      "Allendale Hospital",
      "Beacon Memorial Hospital",
    ]) {
      try {
        app.delete(app.findFirstRecordByData("portal_clients", "name", name));
      } catch (error) {
        if (!String(error).includes("no rows in result set")) throw error;
      }
    }
    clients.fields.removeByName("serviceLine");
    app.save(clients);
  },
);
