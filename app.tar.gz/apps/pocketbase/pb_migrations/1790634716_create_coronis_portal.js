/// <reference path="../pb_data/types.d.ts" />

migrate((app) => {
  const users = app.findCollectionByNameOrId("users");
  users.createRule = "@request.auth.role = 'manager'";
  users.listRule = "id = @request.auth.id || @request.auth.role = 'manager'";
  users.viewRule = "id = @request.auth.id || @request.auth.role = 'manager'";
  users.updateRule = "@request.auth.role = 'manager' || (id = @request.auth.id && @request.body.role:changed = false && @request.body.department:changed = false)";
  users.manageRule = "@request.auth.role = 'manager'";
  users.authRule = "role != ''";

  users.deleteRule = null;
  users.fields.add(new SelectField({ name: "role", maxSelect: 1, values: ["employee", "trainer", "manager"] }));
  users.fields.add(new TextField({ name: "department", max: 100 }));
  try { app.save(users); } catch (err) { throw new Error("USERS_SAVE: " + err); }

  const dates = () => [
    { name: "created", type: "autodate", onCreate: true, onUpdate: false },
    { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
  ];
  const assigned = "@request.auth.id != '' && (@request.auth.role = 'manager' || @request.auth.clients ?= client)";
  const manager = "@request.auth.role = 'manager'";
  const clients = new Collection({
    type: "base", name: "portal_clients",
    listRule: "@request.auth.role = 'manager'",
    viewRule: "@request.auth.role = 'manager'",
    createRule: manager, updateRule: manager, deleteRule: manager,
    fields: [
      { name: "name", type: "text", required: true, max: 160 },
      { name: "code", type: "text", max: 40 },
      { name: "description", type: "text", max: 500 },
      ...dates(),
    ],
  });
  try { app.save(clients); } catch (err) { throw new Error("clients initial: " + err); }
  users.fields.add(new RelationField({ name: "clients", collectionId: clients.id, maxSelect: 200 }));
  users.updateRule = "@request.auth.role = 'manager' || (id = @request.auth.id && @request.body.role:changed = false && @request.body.department:changed = false && @request.body.clients:changed = false)";
  try { app.save(users); } catch (err) { throw new Error("users clients relation: " + err); }
  clients.listRule = "@request.auth.id != '' && (@request.auth.role = 'manager' || @request.auth.clients ?= id)";
  clients.viewRule = "@request.auth.id != '' && (@request.auth.role = 'manager' || @request.auth.clients ?= id)";
  try { app.save(clients); } catch (err) { throw new Error("clients access: " + err); }

  const clientField = () => ({ name: "client", type: "relation", required: true, maxSelect: 1, collectionId: clients.id });
  const sops = new Collection({
    type: "base", name: "portal_sops",
    listRule: assigned + " && (status = 'Published' || @request.auth.role = 'manager' || @request.auth.role = 'trainer')", viewRule: assigned + " && (status = 'Published' || @request.auth.role = 'manager' || @request.auth.role = 'trainer')",
    createRule: "@request.auth.role = 'manager' || (@request.auth.role = 'trainer' && @request.auth.clients ?= @request.body.client && @request.body.status != 'Published')",
    updateRule: "@request.auth.role = 'manager' || (@request.auth.role = 'trainer' && @request.auth.clients ?= client && @request.body.client:changed = false && @request.body.status:changed = false && @request.body.owner:changed = false)",
    deleteRule: manager,
    fields: [
      { name: "title", type: "text", required: true, max: 220 },
      { name: "summary", type: "text", max: 2000 },
      clientField(),
      { name: "vertical", type: "select", required: true, maxSelect: 1, values: ["Charge Entry", "Payment Posting", "AR", "Authorization", "Eligibility", "Coding"] },
      { name: "serviceLine", type: "select", maxSelect: 1, values: ["Hospital", "Physician", "FQHC", "RHC", "Behavioral Health", "EMS", "Lab & Path"] },
      { name: "denialType", type: "text", max: 120 },
      { name: "scenario", type: "text", max: 160 },
      { name: "status", type: "select", maxSelect: 1, values: ["Draft", "Published", "Archived"] },
      { name: "owner", type: "relation", maxSelect: 1, collectionId: users.id },
      ...dates(),
    ],
    indexes: ["CREATE INDEX idx_portal_sops_client ON portal_sops (client)", "CREATE INDEX idx_portal_sops_vertical ON portal_sops (vertical)"],
  });
  try { app.save(sops); } catch (err) { throw new Error("sops: " + err); }

  const versions = new Collection({
    type: "base", name: "portal_versions", listRule: "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))", viewRule: "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))",
    createRule: "@request.auth.role = 'manager' || @request.auth.role = 'trainer'", updateRule: null, deleteRule: null,
    fields: [
      { name: "sop", type: "relation", required: true, maxSelect: 1, collectionId: sops.id, cascadeDelete: true },
      { name: "version", type: "text", required: true, max: 30 },
      { name: "changeNote", type: "text", max: 1000 },
      { name: "document", type: "file", required: true, maxSelect: 1, maxSize: 20971520, protected: true, mimeTypes: ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"] },
      { name: "uploadedBy", type: "relation", maxSelect: 1, collectionId: users.id },
      ...dates(),
    ],
    indexes: ["CREATE UNIQUE INDEX idx_portal_version_unique ON portal_versions (sop, version)"],
  });
  try { app.save(versions); } catch (err) { throw new Error("versions: " + err); }

  const quizzes = new Collection({
    type: "base", name: "portal_quizzes", listRule: "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))", viewRule: "@request.auth.id != '' && (@request.auth.role = 'manager' || (@request.auth.clients ?= sop.client && (sop.status = 'Published' || @request.auth.role = 'trainer')))",
    createRule: "@request.auth.role = 'manager' || @request.auth.role = 'trainer'", updateRule: "@request.auth.role = 'manager' || (@request.auth.role = 'trainer' && @request.auth.clients ?= sop.client && @request.body.sop:changed = false)", deleteRule: manager,
    fields: [
      { name: "sop", type: "relation", required: true, maxSelect: 1, collectionId: sops.id, cascadeDelete: true },
      { name: "title", type: "text", required: true, max: 180 },
      { name: "questions", type: "json", maxSize: 100000 },
      { name: "caseStudy", type: "text", max: 5000 },
      ...dates(),
    ],
  });
  try { app.save(quizzes); } catch (err) { throw new Error("quizzes: " + err); }

  app.save(new Collection({
    type: "base", name: "portal_attempts", listRule: "@request.auth.id = member || @request.auth.role = 'manager'", viewRule: "@request.auth.id = member || @request.auth.role = 'manager'",
    createRule: "@request.auth.id != '' && @request.auth.id = @request.body.member && (@request.auth.role = 'manager' || (@request.auth.clients ?= quiz.sop.client && quiz.sop.status = 'Published'))", updateRule: null, deleteRule: null,
    fields: [
      { name: "member", type: "relation", required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
      { name: "quiz", type: "relation", required: true, maxSelect: 1, collectionId: quizzes.id },
      { name: "answers", type: "json", maxSize: 10000 },
      { name: "score", type: "number", onlyInt: true, min: 0, max: 100 },
      { name: "points", type: "number", onlyInt: true, min: 0, max: 100 },
      ...dates(),
    ],
  }));

  app.save(new Collection({
    type: "base", name: "portal_activity", listRule: "@request.auth.id = member || @request.auth.role = 'manager'", viewRule: "@request.auth.id = member || @request.auth.role = 'manager'",
    createRule: "@request.auth.id != '' && @request.auth.id = @request.body.member", updateRule: null, deleteRule: null,
    fields: [
      { name: "member", type: "relation", required: true, maxSelect: 1, collectionId: users.id, cascadeDelete: true },
      { name: "eventType", type: "select", required: true, maxSelect: 1, values: ["login", "page_view", "sop_view", "sop_time", "production_use", "quiz_complete", "resource_open"] },
      { name: "sop", type: "relation", maxSelect: 1, collectionId: sops.id },
      { name: "seconds", type: "number", onlyInt: true, min: 0, max: 86400 },
      { name: "detail", type: "text", max: 300 },
      ...dates(),
    ],
  }));

  app.save(new Collection({
    type: "base", name: "portal_resources", listRule: "@request.auth.id != ''", viewRule: "@request.auth.id != ''",
    createRule: manager, updateRule: manager, deleteRule: manager,
    fields: [
      { name: "title", type: "text", required: true, max: 180 },
      { name: "category", type: "select", required: true, maxSelect: 1, values: ["Payer portal", "Medicare form", "Insurance contact", "TFL reference", "External tool"] },
      { name: "url", type: "url" },
      { name: "phone", type: "text", max: 80 },
      { name: "notes", type: "text", max: 1000 },
      ...dates(),
    ],
  }));

  app.save(new Collection({
    type: "base", name: "portal_audit", listRule: "@request.auth.role = 'manager'", viewRule: "@request.auth.role = 'manager'", createRule: null, updateRule: null, deleteRule: null,
    fields: [
      { name: "actor", type: "relation", maxSelect: 1, collectionId: users.id },
      { name: "eventType", type: "text", required: true, max: 100 },
      { name: "targetCollection", type: "text", max: 100 },
      { name: "recordId", type: "text", max: 50 },
      { name: "detail", type: "text", max: 500 },
      ...dates(),
    ],
  }));
}, (app) => {
  ["portal_audit", "portal_resources", "portal_activity", "portal_attempts", "portal_quizzes", "portal_versions", "portal_sops"].forEach(name => app.delete(app.findCollectionByNameOrId(name)));
  const users = app.findCollectionByNameOrId("users");
  users.fields.removeByName("clients");
  users.fields.removeByName("department");
  users.fields.removeByName("role");
  users.createRule = "";
  users.listRule = "id = @request.auth.id";
  users.viewRule = "id = @request.auth.id";
  users.updateRule = "id = @request.auth.id";
  users.deleteRule = "id = @request.auth.id";
  users.manageRule = null;
  users.authRule = "";
  app.save(users);
  app.delete(app.findCollectionByNameOrId("portal_clients"));
});
