/// <reference path="../pb_data/types.d.ts" />

// Answer keys are never sent to employees taking an assessment.
onRecordEnrich((e) => {
  const auth = e.requestInfo.auth;
  if (auth && auth.get("role") === "employee") {
    const questions = JSON.parse(JSON.stringify(e.record.get("questions") || []));
    if (Array.isArray(questions)) {
      e.record.set("questions", questions.map(q => ({ prompt: q.prompt, options: q.options })));
    }
  }
  e.next();
}, "portal_quizzes");
