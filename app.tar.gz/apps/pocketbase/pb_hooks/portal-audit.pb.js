/// <reference path="../pb_data/types.d.ts" />

// Record-level audit trail. Append-only collection is not writable through the public API.
onRecordAfterCreateSuccess((e) => {
  const name = e.record.collection().name;
  const watched = ["portal_clients", "portal_sops", "portal_versions", "portal_quizzes", "portal_attempts", "portal_activity", "portal_resources", "users"];
  if (watched.indexOf(name) >= 0) {
    try {
      const col = $app.findCollectionByNameOrId("portal_audit");
      const audit = new Record(col);
      const actor = e.requestInfo && e.requestInfo.auth;
      audit.set("actor", actor ? actor.id : (name === "portal_activity" || name === "portal_attempts" ? e.record.get("member") : ""));
      audit.set("eventType", name === "portal_activity" ? String(e.record.get("eventType")) : "create");
      audit.set("targetCollection", name);
      audit.set("recordId", e.record.id);
      $app.save(audit);
    } catch (err) {
      $app.logger().error("Portal audit create failed", "error", String(err));
    }
  }
  e.next();
});

onRecordAfterUpdateSuccess((e) => {
  const name = e.record.collection().name;
  if (["portal_clients", "portal_sops", "portal_quizzes", "portal_resources", "users"].indexOf(name) >= 0) {
    try {
      const col = $app.findCollectionByNameOrId("portal_audit");
      const audit = new Record(col);
      const actor = e.requestInfo && e.requestInfo.auth;
      audit.set("actor", actor ? actor.id : "");
      audit.set("eventType", "update");
      audit.set("targetCollection", name);
      audit.set("recordId", e.record.id);
      $app.save(audit);
    } catch (err) {
      $app.logger().error("Portal audit update failed", "error", String(err));
    }
  }
  e.next();
});

onRecordAfterDeleteSuccess((e) => {
  const name = e.record.collection().name;
  if (["portal_clients", "portal_sops", "portal_quizzes", "portal_resources", "users"].indexOf(name) >= 0) {
    try {
      const col = $app.findCollectionByNameOrId("portal_audit");
      const audit = new Record(col);
      const actor = e.requestInfo && e.requestInfo.auth;
      audit.set("actor", actor ? actor.id : "");
      audit.set("eventType", "delete");
      audit.set("targetCollection", name);
      audit.set("recordId", e.record.id);
      $app.save(audit);
    } catch (err) {
      $app.logger().error("Portal audit delete failed", "error", String(err));
    }
  }
  e.next();
});

// Do not trust client-submitted quiz scores or points.
onRecordCreateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (!auth || e.record.get("member") !== auth.id) throw new ForbiddenError("Not authorized");
  const quiz = $app.findRecordById("portal_quizzes", e.record.get("quiz"));
  const sop = $app.findRecordById("portal_sops", quiz.get("sop"));
  const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
  if (auth.get("role") !== "manager" && assigned.indexOf(sop.get("client")) < 0) throw new ForbiddenError("Not assigned to this client");
  const questions = JSON.parse(JSON.stringify(quiz.get("questions") || []));
  const answers = JSON.parse(JSON.stringify(e.record.get("answers") || []));
  const valid = Array.isArray(questions) ? questions.filter(q => q && Array.isArray(q.options) && Number.isInteger(q.correctIndex) && q.correctIndex >= 0 && q.correctIndex < q.options.length) : [];
  if (!valid.length || !Array.isArray(answers)) throw new BadRequestError("Invalid quiz");
  let correct = 0;
  valid.forEach((q, i) => { if (answers[i] === q.correctIndex) correct++; });
  const score = Math.round(correct / valid.length * 100);
  e.record.set("score", score);
  e.record.set("points", Math.round(score / 10));
  e.next();
}, "portal_attempts");

// Event submissions must reference only SOPs that the caller may access.
onRecordCreateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (!auth || e.record.get("member") !== auth.id) throw new ForbiddenError("Not authorized");
  if (e.record.get("sop")) {
    const sop = $app.findRecordById("portal_sops", e.record.get("sop"));
    const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
    if (auth.get("role") !== "manager" && assigned.indexOf(sop.get("client")) < 0) throw new ForbiddenError("Not assigned to this client");
  }
  e.next();
}, "portal_activity");

// Auth was removed from the portal, so unauthenticated SOP version uploads
// are allowed (createRule is ""). Role/client checks only apply when a user
// is actually signed in.
onRecordCreateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (!auth) { e.next(); return; }
  const sop = $app.findRecordById("portal_sops", e.record.get("sop"));
  const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
  if (auth.get("role") !== "manager" && (auth.get("role") !== "trainer" || assigned.indexOf(sop.get("client")) < 0)) throw new ForbiddenError("Not assigned to this client");
  e.record.set("uploadedBy", auth.id);
  e.next();
}, "portal_versions");
