/// <reference path="../pb_data/types.d.ts" />

// Defense in depth: validate referenced client and publication rights on writes.
// Auth was removed from the portal, so unauthenticated requests are allowed;
// role/client checks only apply when a user is actually signed in.
onRecordCreateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (auth) {
    const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
    if (auth.get("role") !== "manager" && (auth.get("role") !== "trainer" || assigned.indexOf(e.record.get("client")) < 0 || e.record.get("status") === "Published")) throw new ForbiddenError("Not assigned to this client");
    e.record.set("owner", auth.id);
  }
  e.next();
}, "portal_sops");

onRecordCreateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (!auth) { e.next(); return; }
  const sop = $app.findRecordById("portal_sops", e.record.get("sop"));
  const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
  if (auth.get("role") !== "manager" && (auth.get("role") !== "trainer" || assigned.indexOf(sop.get("client")) < 0)) throw new ForbiddenError("Not assigned to this client");
  e.next();
}, "portal_quizzes");

onRecordUpdateRequest((e) => {
  const auth = e.requestInfo.auth;
  if (!auth) { e.next(); return; }
  const assigned = JSON.parse(JSON.stringify(auth.get("clients") || []));
  if (auth.get("role") !== "manager" && (auth.get("role") !== "trainer" || assigned.indexOf(e.record.get("client")) < 0 || e.record.get("status") === "Published")) throw new ForbiddenError("Not authorized to publish");
  e.next();
}, "portal_sops");
