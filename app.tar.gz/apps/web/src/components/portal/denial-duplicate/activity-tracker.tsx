import { useEffect, useRef, useState } from 'react';
import { Activity, Clock, Eye, Fingerprint, LogIn, LogOut, Timer, UserCircle2 } from 'lucide-react';
import pb from '@/lib/pocketbase-client';
import { useAuth } from '@/hooks/use-auth';
import { friendlyError, logActivity, roleLabel } from '@/lib/portal';

const SCREEN_KEY = 'denial/duplicate';

type Stat = { views: number; totalSeconds: number; lastAccess: string | null };

function fmtDuration(total: number) {
  const s = Math.max(0, Math.floor(total));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m ${sec}s`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

export function ActivityTracker() {
  const { user, isAuthed, isLoading, login, logout } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signInError, setSignInError] = useState('');
  const [signingIn, setSigningIn] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [stat, setStat] = useState<Stat>({ views: 0, totalSeconds: 0, lastAccess: null });
  const [statBusy, setStatBusy] = useState(false);
  const enteredAt = useRef(Date.now());
  const loggedSeconds = useRef(0);

  // Sign-in handler
  async function handleSignIn(event: React.FormEvent) {
    event.preventDefault();
    setSigningIn(true);
    setSignInError('');
    try {
      await login(email.trim(), password);
      setEmail('');
      setPassword('');
    } catch (err) {
      setSignInError(friendlyError(err));
    } finally {
      setSigningIn(false);
    }
  }

  // Track time on screen + log page_view / sop_time for the signed-in employee.
  useEffect(() => {
    if (!isAuthed) return;
    enteredAt.current = Date.now();
    loggedSeconds.current = 0;

    // Log a page view footprint on entry (counts "how many times checked").
    void logActivity('page_view', SCREEN_KEY).catch(() => {});

    // Refresh stats for this employee on this screen.
    setStatBusy(true);
    pb.collection('portal_activity')
      .getFullList<{ eventType: string; seconds: number; detail: string; created: string }>({
        filter: pb.filter('member = {:uid} && detail = {:screen}', { uid: user?.id, screen: SCREEN_KEY }),
        sort: '-created',
        requestKey: `dup-stats-${user?.id}`,
      })
      .then((rows) => {
        const views = rows.filter((r) => r.eventType === 'page_view').length;
        const totalSeconds = rows.filter((r) => r.eventType === 'sop_time').reduce((sum, r) => sum + (r.seconds || 0), 0);
        const lastAccess = rows[0]?.created || null;
        setStat({ views, totalSeconds, lastAccess });
      })
      .catch(() => {})
      .finally(() => setStatBusy(false));

    const tick = window.setInterval(() => {
      if (document.visibilityState === 'visible') {
        const elapsed = Math.round((Date.now() - enteredAt.current) / 1000);
        setSessionSeconds(elapsed);
        if (elapsed - loggedSeconds.current >= 30) {
          const chunk = elapsed - loggedSeconds.current;
          loggedSeconds.current = elapsed;
          void logActivity('sop_time', SCREEN_KEY, '', Math.min(86400, chunk)).catch(() => {});
          setStat((prev) => ({ ...prev, totalSeconds: prev.totalSeconds + chunk }));
        }
      } else {
        enteredAt.current = Date.now();
      }
    }, 1000);

    const onVisibility = () => { enteredAt.current = Date.now(); };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      window.clearInterval(tick);
      document.removeEventListener('visibilitychange', onVisibility);
      const remaining = Math.round((Date.now() - enteredAt.current) / 1000) - loggedSeconds.current;
      if (remaining >= 5 && document.visibilityState === 'visible') {
        void logActivity('sop_time', SCREEN_KEY, '', Math.min(86400, remaining)).catch(() => {});
      }
    };
  }, [isAuthed, user?.id]);

  if (isLoading) {
    return (
      <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6">
        <p className="text-[12px] text-[#8291a1]">Loading activity tracker...</p>
      </section>
    );
  }

  // Not signed in — show inline sign-in so the employee is identified for tracking.
  if (!isAuthed) {
    return (
      <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-7">
        <div className="mb-5 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#eaf0ff] text-[#274fce]"><Activity size={19} /></span>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">EMPLOYEE ACTIVITY TRACKING</p>
            <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">Sign in to record your footprint</h2>
          </div>
        </div>
        <p className="mb-4 rounded-lg bg-[#f7f9fc] px-4 py-3 text-[12px] leading-relaxed text-[#5d7187]">
          Sign in so the portal can track your name, employee ID, time on screen, and how many times you reviewed this
          duplicate-denial workflow. Managers use this to confirm every employee checked the latest client-specific SOP.
        </p>
        <form onSubmit={handleSignIn} className="grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
          <input
            type="email"
            required
            className="portal-input"
            placeholder="Employee email"
            aria-label="Employee email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            required
            className="portal-input"
            placeholder="Password"
            aria-label="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button disabled={signingIn} className="portal-button">
            <LogIn size={16} /> {signingIn ? 'Signing in...' : 'Sign in'}
          </button>
        </form>
        {signInError && (
          <p className="mt-3 rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-[11px] text-red-700">{signInError}</p>
        )}
      </section>
    );
  }

  const name = user?.name || user?.email || 'Employee';
  const initials = (name.split(' ').map((p: string) => p[0]).join('').slice(0, 2) || 'EM').toUpperCase();

  return (
    <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-7">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#eaf0ff] text-[#274fce]"><Activity size={19} /></span>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">EMPLOYEE ACTIVITY TRACKING</p>
            <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">Your footprint on this workflow</h2>
          </div>
        </div>
        <button onClick={() => logout()} className="portal-button-outline min-h-9 px-3 text-[11px]">
          <LogOut size={14} /> Sign out
        </button>
      </div>

      {/* Employee identity */}
      <div className="mb-5 flex flex-wrap items-center gap-4 rounded-xl border border-[#edf1f5] bg-[#fbfcfe] p-4">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#274fce] text-[14px] font-bold text-white">{initials}</span>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 text-[14px] font-bold text-[#283d52]"><UserCircle2 size={16} className="text-[#5d78c7]" /> {name}</p>
          <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-[#8291a1]">
            <span className="flex items-center gap-1"><Fingerprint size={12} /> ID: <span className="font-mono font-semibold text-[#5d7187]">{user?.id}</span></span>
            <span>Role: <span className="font-semibold text-[#5d7187]">{roleLabel[(user?.role as 'employee' | 'trainer' | 'manager') || 'employee']}</span></span>
            {user?.department && <span>Dept: <span className="font-semibold text-[#5d7187]">{user.department}</span></span>}
          </p>
        </div>
      </div>

      {/* Live + cumulative stats */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<Timer size={17} />} label="Time on this screen (live)" value={fmtDuration(sessionSeconds)} tone="live" />
        <StatCard icon={<Clock size={17} />} label="Total time on this workflow" value={fmtDuration(stat.totalSeconds)} tone="cumulative" />
        <StatCard icon={<Eye size={17} />} label="Times reviewed this SOP" value={String(stat.views)} tone="views" />
        <StatCard
          icon={<Activity size={17} />}
          label="Last access"
          value={stat.lastAccess ? new Date(stat.lastAccess).toLocaleString() : '—'}
          tone="last"
          small
        />
      </div>

      <p className="mt-4 flex items-center gap-1.5 text-[11px] text-[#8291a1]">
        {statBusy ? 'Refreshing your stats...' : 'Tracking is active while this screen is open. Time is logged every 30 seconds and on exit.'}
      </p>
    </section>
  );
}

function StatCard({
  icon,
  label,
  value,
  tone,
  small,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: 'live' | 'cumulative' | 'views' | 'last';
  small?: boolean;
}) {
  const toneMap: Record<string, string> = {
    live: 'bg-[#eaf0ff] text-[#274fce]',
    cumulative: 'bg-[#eaf6ef] text-[#2f7a52]',
    views: 'bg-[#fff2e9] text-[#c57b44]',
    last: 'bg-[#f0f3f8] text-[#647589]',
  };
  return (
    <div className="rounded-xl border border-[#edf1f5] bg-white p-4">
      <div className="mb-2 flex items-center gap-2">
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone]}`}>{icon}</span>
        <p className="text-[10px] font-bold uppercase tracking-wide text-[#8291a1]">{label}</p>
      </div>
      <p className={`font-display font-bold text-[#283d52] ${small ? 'text-[13px]' : 'text-[20px]'}`}>{value}</p>
    </div>
  );
}
