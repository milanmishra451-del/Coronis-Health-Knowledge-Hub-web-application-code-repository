import { useEffect, useState } from 'react';
import { Building2, Download, FileText, Loader2, RefreshCw, Stethoscope } from 'lucide-react';
import pb from '@/lib/pocketbase-client';
import { type PortalClient, type Sop, type Version, friendlyError } from '@/lib/portal';

const CLIENT_NAME = 'Beacon Memorial Hospital';

/**
 * Beacon Memorial Hospital — client-specific notes for the "Claim denied as
 * Duplicate" AR scenario. These sit on top of the generic on-call workflow so
 * every employee follows the client's own SOP update alongside the denial
 * decision tree. The uploaded SOP document is pulled from the backend so the
 * latest approved version is always the source of truth.
 */
const clientNotes: { title: string; body: string }[] = [
  {
    title: 'Clearinghouse & corrected-claim routing',
    body: 'Beacon Memorial Hospital corrected claims are submitted through the Beacon clearinghouse portal with billing code "7". Always reference the original claim number returned by the rep before resubmission.',
  },
  {
    title: 'Modifier handling for same-DOS services',
    body: 'When rendering providers differ on the same DOS, append modifier 77 and resubmit the corrected claim. When rendering providers match but exam times differ, append modifier 76. Confirm the modifier against the medical record before sending.',
  },
  {
    title: 'Medicare & Medicare Advantage rule',
    body: 'Beacon Memorial Hospital Medicare and Medicare Advantage claims do not accept corrected claims. Send a fresh claim to Medicare instead of a corrected claim, and document the fresh-claim reference in the AR notes.',
  },
  {
    title: 'Reprocess TAT & follow-up',
    body: 'Set the AR follow-up for the reprocessing TAT quoted by the rep (standard Beacon Memorial TAT is 48–72 hours). If the rep does not quote a TAT, default to 7 calendar days and flag the account for supervisor review.',
  },
  {
    title: 'Appeal time-limit calculation',
    body: 'Calculate the appeal time limit from the denial date on the Beacon Memorial remit. If the limit has not crossed, send the appeal document to the fax/address provided by the rep. If crossed, route to the client lead before writing off — Beacon Memorial may still request the document per client instructions.',
  },
  {
    title: 'Charge voiding & coding clarification',
    body: 'When modifier, rendering provider, and exam time all match on the duplicate DOS, the charge must be voided. For any void over the Beacon Memorial threshold, raise a coding-team clarification ticket first and wait for confirmation before voiding.',
  },
];

export function ClientInstructions() {
  const [sops, setSops] = useState<Sop[]>([]);
  const [versions, setVersions] = useState<Record<string, Version[]>>({});
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [downloading, setDownloading] = useState<string>('');

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const clients = await pb.collection('portal_clients').getFullList<PortalClient>({
          filter: pb.filter('name = {:name}', { name: CLIENT_NAME }),
        });
        if (!active) return;
        const matched = clients[0];
        if (!matched) { setBusy(false); return; }
        const list = await pb.collection('portal_sops').getFullList<Sop>({
          filter: pb.filter('client = {:cid} && vertical = "AR"', { cid: matched.id }),
          sort: '-updated',
        });
        if (!active) return;
        setSops(list);
        const bySop: Record<string, Version[]> = {};
        await Promise.all(list.map((s, i) =>
          pb.collection('portal_versions').getFullList<Version>({
            filter: pb.filter('sop = {:id}', { id: s.id }),
            sort: '-created',
            requestKey: `dup-versions-${s.id}-${i}`,
          }).then((v) => { bySop[s.id] = v; }).catch(() => { bySop[s.id] = []; }),
        ));
        if (active) setVersions(bySop);
      } catch (err) {
        if (active) setError(friendlyError(err));
      } finally {
        if (active) setBusy(false);
      }
    })();
    return () => { active = false; };
  }, []);

  async function download(version: Version) {
    setDownloading(version.id);
    try {
      // The document field is not protected, so the file is reachable
      // without a token. Only request a token when a user is signed in;
      // for anonymous visitors fall back to the plain file URL.
      let url: string;
      if (pb.authStore.isValid) {
        try {
          const token = await pb.files.getToken();
          url = pb.files.getURL(version, version.document, { token, download: true });
        } catch {
          url = pb.files.getURL(version, version.document, { download: true });
        }
      } else {
        url = pb.files.getURL(version, version.document, { download: true });
      }
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (err) {
      setError(friendlyError(err));
    } finally {
      setDownloading('');
    }
  }

  return (
    <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-7">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#eaf0ff] text-[#274fce]"><Building2 size={19} /></span>
        <div className="flex-1">
          <p className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">CLIENT-SPECIFIC SOP INSTRUCTIONS</p>
          <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">{CLIENT_NAME} · Duplicate denial</h2>
        </div>
        <span className="hidden items-center gap-1.5 rounded-full border border-[#b9d7c2] bg-[#eaf6ef] px-3 py-1.5 text-[11px] font-bold text-[#2f7a52] sm:inline-flex">
          <Stethoscope size={14} /> Hospital · AR
        </span>
      </div>

      <p className="mb-5 rounded-lg bg-[#f7f9fc] px-4 py-3 text-[12px] leading-relaxed text-[#5d7187]">
        Follow these Beacon Memorial Hospital instructions together with the on-call scenario decision tree below.
        Always confirm against the latest approved SOP document before taking action on a live claim.
      </p>

      {error && (
        <div role="alert" className="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-[11px] text-red-700">
          {error}
        </div>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {clientNotes.map((note, i) => (
          <div key={i} className="rounded-xl border border-[#edf1f5] bg-[#fbfcfe] p-4">
            <p className="mb-1.5 flex items-center gap-2 text-[12px] font-bold text-[#274fce]">
              <span className="flex h-5 w-5 items-center justify-center rounded bg-[#eaf0ff] text-[10px]">{i + 1}</span>
              {note.title}
            </p>
            <p className="text-[12px] leading-relaxed text-[#3d5165]">{note.body}</p>
          </div>
        ))}
      </div>

      {/* Uploaded SOP documents for this client + vertical */}
      <div className="mt-6 border-t border-[#edf1f5] pt-5">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#467aa7]">Latest approved SOP documents</p>
          {busy && <Loader2 size={14} className="animate-spin text-[#9aa8b5]" />}
        </div>

        {busy ? (
          <p className="rounded-lg border border-[#edf1f5] bg-[#fbfcfe] px-4 py-3 text-[12px] text-[#8291a1]">Loading Beacon Memorial SOPs...</p>
        ) : sops.length === 0 ? (
          <p className="rounded-lg border border-[#edf1f5] bg-[#fbfcfe] px-4 py-3 text-[12px] text-[#8291a1]">
            No AR SOP uploaded for {CLIENT_NAME} yet. Use <strong>Upload SOP</strong> in the library to add the latest approved document.
          </p>
        ) : (
          <div className="space-y-3">
            {sops.map((sop) => {
              const vs = versions[sop.id] || [];
              const latest = vs[0];
              return (
                <div key={sop.id} className="flex flex-wrap items-start gap-3 rounded-xl border border-[#e2e9f1] p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#eaf0ff] text-[#3157c6]"><FileText size={19} /></span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-bold text-[#2d4257]">{sop.title}</p>
                    <p className="mt-0.5 text-[11px] text-[#8d9dae]">{sop.summary || 'No summary provided.'}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[10px]">
                      <span className={`rounded-full px-2 py-0.5 font-bold ${sop.status === 'Published' ? 'bg-[#e7f5ed] text-[#31805a]' : 'bg-[#fff2dc] text-[#976b28]'}`}>{sop.status || 'Draft'}</span>
                      {latest && <span className="rounded-full bg-[#f0f3f8] px-2 py-0.5 text-[#647589]">Version {latest.version}</span>}
                      {latest && <span className="text-[#9aa8b5]">Updated {new Date(latest.created).toLocaleDateString()}</span>}
                      <span className="text-[#9aa8b5]">{vs.length} version{vs.length === 1 ? '' : 's'}</span>
                    </div>
                  </div>
                  {latest && (
                    <button
                      onClick={() => void download(latest)}
                      disabled={downloading === latest.id}
                      className="portal-button-outline min-h-9 px-3"
                      aria-label={`Download ${sop.title} version ${latest.version}`}
                    >
                      {downloading === latest.id ? <RefreshCw size={15} className="animate-spin" /> : <Download size={15} />}
                      <span className="hidden sm:inline">Open SOP</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
