import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router';
import { Activity, ArrowRight, BookOpen, ChartNoAxesCombined, ChevronDown, Command, FileText, LayoutGrid, LifeBuoy, LogOut, Menu, Search, Settings2, ShieldCheck, Users, X } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { currentRole, logActivity, roleLabel } from '@/lib/portal';
import { SopChatbot } from '@/components/portal/sop-chatbot';

const navigation = [
  { to: '/portal', label: 'Overview', icon: LayoutGrid, end: true },
  { to: '/portal/library', label: 'SOP library', icon: BookOpen },
  { to: '/portal/resources', label: 'Resource center', icon: LifeBuoy },
  { to: '/portal/reports', label: 'Reports & insights', icon: ChartNoAxesCombined },
  { to: '/portal/team', label: 'Team & access', icon: Users },
];

export function PortalShell() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const role = currentRole();
  useEffect(() => { setMobileOpen(false); void logActivity('page_view', location.pathname).catch(() => {}); }, [location.pathname]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); setSearchOpen(true); }
      if (event.key === 'Escape') setSearchOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const signOut = () => { logout(); navigate('/', { replace: true }); };
  const initials = (user?.name || user?.email || 'CH').split(/[\s@]+/).slice(0, 2).map((part: string) => part[0]?.toUpperCase()).join('');
  return <div className="portal-app min-h-screen bg-background text-foreground">
    {mobileOpen && <button className="fixed inset-0 z-30 bg-[#081624]/50 lg:hidden" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <aside className={`portal-sidebar fixed inset-y-0 left-0 z-40 flex w-[258px] flex-col border-r border-[#dce4ec] bg-white transition-transform lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex h-[88px] items-center gap-3 border-b border-[#e8edf1] px-6">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-white shadow-[3px_3px_0_#b8c8f8]"><Activity size={23} strokeWidth={2.5} /></div>
        <div><div className="font-display text-[20px] font-bold leading-none tracking-tight">coronis<span className="text-primary">.</span></div><div className="mt-1.5 text-[9px] font-bold uppercase tracking-[.21em] text-[#7e8c9b]">HEALTH · KNOWLEDGE HUB</div></div>
        <button onClick={() => setMobileOpen(false)} aria-label="Close navigation" className="ml-auto lg:hidden"><X size={20} /></button>
      </div>
      <div className="px-4 pt-7"><p className="px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#91a0af]">Workspace</p>
        <nav className="mt-3 space-y-1" aria-label="Main navigation">{navigation.filter(item => item.to !== '/portal/team' || role === 'manager').map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `group flex min-h-11 items-center gap-3 rounded-[10px] px-3 text-[13px] font-semibold transition-colors ${isActive ? 'bg-[#eaf0ff] text-[#2148c7]' : 'text-[#536273] hover:bg-[#f4f6f8] hover:text-[#17283a]'}`}><Icon size={18} strokeWidth={1.9} />{label}<ArrowRight size={14} className="ml-auto opacity-0 transition-opacity group-hover:opacity-100" /></NavLink>)}</nav>
      </div>
      <div className="mt-8 px-4"><p className="px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#91a0af]">Quick access</p><Link to="/portal/library?vertical=AR" className="mt-3 flex items-center gap-3 rounded-[10px] px-3 py-2.5 text-[13px] font-medium text-[#687788] hover:bg-[#f4f6f8]"><FileText size={17} /> AR workflows</Link><Link to="/portal/resources?category=Medicare+form" className="flex items-center gap-3 rounded-[10px] px-3 py-2.5 text-[13px] font-medium text-[#687788] hover:bg-[#f4f6f8]"><ShieldCheck size={17} /> Medicare forms</Link></div>
      <div className="mt-auto p-4"><div className="rounded-xl border border-[#dce7f4] bg-[#f3f7fd] p-4"><div className="flex items-center gap-2 text-xs font-bold text-[#3154ad]"><ShieldCheck size={16} /> Security reminder</div><p className="mt-2 text-[11px] leading-relaxed text-[#6d7b8c]">Use approved, de-identified training materials. Do not upload patient information.</p></div><button onClick={signOut} className="mt-4 flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-xs font-semibold text-[#69788a] hover:bg-[#f4f6f8] hover:text-[#17283a]"><LogOut size={16} /> Sign out</button></div>
    </aside>
    <div className="lg:pl-[258px]">
      <header className="sticky top-0 z-20 flex h-[76px] items-center justify-between gap-4 border-b border-[#e5eaf0] bg-white/95 px-5 backdrop-blur-md md:px-9">
        <div className="flex items-center gap-3"><button onClick={() => setMobileOpen(true)} aria-label="Open navigation" className="rounded-lg p-2 text-[#344559] lg:hidden"><Menu size={21} /></button><div className="hidden text-xs font-semibold text-[#8190a0] sm:block">Coronis Health <span className="mx-2 text-[#c4ced7]">/</span> <span className="text-[#25384b]">SOP Portal</span></div></div>
        <div className="flex items-center gap-3"><button onClick={() => setSearchOpen(true)} className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#e0e7ef] text-[#687b8e] hover:bg-[#f5f7fb] md:w-[270px] md:justify-start md:gap-2 md:px-3"><Search size={17} /><span className="hidden text-xs text-[#97a3b1] md:block">Search SOPs and resources</span><kbd className="ml-auto hidden rounded border border-[#dce3eb] px-1.5 py-0.5 text-[10px] text-[#9aa8b6] md:block">⌘ K</kbd></button><div className="hidden h-7 w-px bg-[#e5eaf0] sm:block" /><div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e4eafa] text-xs font-bold text-[#2649bb]">{initials}</div><div className="hidden sm:block"><p className="max-w-[160px] truncate text-xs font-bold text-[#233548]">{user?.name || user?.email}</p><p className="mt-0.5 text-[10px] text-[#8291a1]">{roleLabel[role]}</p></div><ChevronDown size={14} className="hidden text-[#8b9aaa] sm:block" /></div>
      </header>
      <main className="min-h-[calc(100vh-76px)]"><Outlet /></main>
    </div>
    {searchOpen && <div className="fixed inset-0 z-50 flex items-start justify-center bg-[#091626]/55 px-4 pt-[12vh]" onMouseDown={() => setSearchOpen(false)}><div className="w-full max-w-xl overflow-hidden rounded-2xl bg-white shadow-2xl" onMouseDown={event => event.stopPropagation()}><form onSubmit={event => { event.preventDefault(); setSearchOpen(false); navigate(`/portal/library?q=${encodeURIComponent(query)}`); }}><div className="flex items-center gap-3 border-b border-[#e6ebf0] px-5"><Search size={20} className="text-[#607286]" /><input autoFocus value={query} onChange={event => setQuery(event.target.value)} placeholder="Search by SOP, denial type, scenario..." className="h-16 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#a0adba]" /><button type="button" onClick={() => setSearchOpen(false)} className="rounded-md border px-2 py-1 text-[10px] text-[#7b8896]">ESC</button></div></form><div className="p-4"><p className="mb-2 px-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#93a0ad]">Explore</p><Link onClick={() => setSearchOpen(false)} to="/portal/library" className="flex items-center gap-3 rounded-lg px-3 py-3 text-sm hover:bg-[#f4f7fb]"><BookOpen size={18} className="text-primary" /> Browse SOP library <ArrowRight size={15} className="ml-auto" /></Link><Link onClick={() => setSearchOpen(false)} to="/portal/resources" className="flex items-center gap-3 rounded-lg px-3 py-3 text-sm hover:bg-[#f4f7fb]"><Settings2 size={18} className="text-primary" /> Open resource center <ArrowRight size={15} className="ml-auto" /></Link></div><div className="flex items-center gap-2 border-t bg-[#f8fafc] px-5 py-3 text-[11px] text-[#92a0ad]"><Command size={13} /> Press Enter to search the library</div></div></div>}
    <SopChatbot />
  </div>;
}
