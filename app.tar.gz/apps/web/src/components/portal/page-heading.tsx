import type { ReactNode } from 'react';
export function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mb-2.5 text-[10px] font-bold uppercase tracking-[.2em] text-primary">{eyebrow}</p><h1 className="font-display text-[32px] font-bold leading-[1.1] tracking-[-.035em] text-[#14283b] md:text-[38px]">{title}</h1>{description && <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[#748394]">{description}</p>}</div>{action}</div>;
}
