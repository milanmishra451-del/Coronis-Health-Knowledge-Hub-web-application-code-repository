import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { Ambulance, ArrowRight, ArrowUpRight, BookOpen, Brain, Building2, CalendarDays, ChevronRight, Cross, FileText, HeartPulse, Microscope, Plus, Search, ShieldCheck, Stethoscope } from 'lucide-react';
import pb from '@/lib/pocketbase-client';
import { type PortalClient, type Sop, friendlyError, serviceLines, verticals } from '@/lib/portal';
import { PageHeading } from '@/components/portal/page-heading';
import { EmptyState } from '@/components/portal/empty-state';

const tileIcons: Record<string, typeof Building2> = {
  Hospital: Building2,
  Physician: Stethoscope,
  FQHC: HeartPulse,
  RHC: Cross,
  'Behavioral Health': Brain,
  EMS: Ambulance,
  'Lab & Path': Microscope,
};
const accents: Record<string, string> = {
  Hospital: '#e9efff', Physician: '#e9f3f7', FQHC: '#f1edff', RHC: '#eaf4ef',
  'Behavioral Health': '#fff2e9', EMS: '#eaf3fa', 'Lab & Path': '#f5eef8',
};
const ink: Record<string, string> = {
  Hospital: '#3158c9', Physician: '#288298', FQHC: '#6e57bb', RHC: '#3c886b',
  'Behavioral Health': '#c57b44', EMS: '#467aa7', 'Lab & Path': '#8a5d9d',
};
const verticalBlurb: Record<string, string> = {
  'Charge Entry': 'Capture charges accurately before submission.',
  'Payment Posting': 'Post payments and reconcile payer remits.',
  AR: 'Work aging, denials, and appeals to resolution.',
  Authorization: 'Secure prior auth and continued stay approvals.',
  Eligibility: 'Verify benefits and patient responsibility.',
  Coding: 'Apply correct codes and documentation standards.',
};

export function Overview() {
  const [clients, setClients] = useState<PortalClient[]>([]);
  const [sops, setSops] = useState<Sop[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    Promise.all([
      pb.collection('portal_clients').getFullList<PortalClient>({ sort: 'name' }).catch(() => [] as PortalClient[]),
      pb.collection('portal_sops').getFullList<Sop>({ sort: '-updated' }).catch(() => [] as Sop[]),
    ]).then(([c, s]) => { if (active) { setClients(c); setSops(s); } }).catch(err => { if (active) setError(friendlyError(err)); }).finally(() => { if (active) setBusy(false); });
    return () => { active = false; };
  }, []);
  const published = sops.filter(sop => sop.status === 'Published');
  const hospitalClients = clients.filter(client => client.serviceLine === 'Hospital');
  const [today, setToday] = useState('');
  useEffect(() => {
    setToday(new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }));
  }, []);
  return <div className="mx-auto max-w-[1460px] px-5 pb-16 pt-9 md:px-9 md:pt-10">
    <div className="mb-8 flex flex-wrap items-center justify-between gap-3"><span className="flex items-center gap-2 text-xs font-semibold text-[#718397]"><CalendarDays size={15} /> {today || '\u00A0'}</span><span className="flex items-center gap-2 rounded-full border border-[#dce6ef] bg-white px-3 py-1.5 text-[11px] font-semibold text-[#59728a]"><span className="h-1.5 w-1.5 rounded-full bg-[#36a978]" /> Internal workspace</span></div>
    <PageHeading eyebrow="YOUR WORKSPACE / OVERVIEW" title="Coronis Health knowledge hub" description="Start from a care setting or a workflow. Every tile takes you to the approved SOPs for that area." action={<Link to="/portal/library" className="portal-button"><Search size={16} /> Explore all SOPs</Link>} />
    {error && <div role="alert" className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">Some details could not be loaded: {error} <button className="ml-2 underline" onClick={() => window.location.reload()}>Try again</button></div>}

    <div className="mb-5 flex items-end justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#3259ca]">BROWSE BY CARE SETTING</p><h2 className="mt-2 font-display text-[23px] font-bold tracking-tight text-[#1e3449]">Client workspaces</h2><p className="mt-1.5 text-xs text-[#8291a1]">Seven care verticals, each with its own procedure library.</p></div></div>
    <section className="mb-12 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4" aria-label="Care setting tiles">
      {serviceLines.map((line) => {
        const Icon = tileIcons[line] || BookOpen;
        const count = published.filter(sop => sop.serviceLine === line).length;
        return (
          <Link key={line} to={`/portal/library?serviceLine=${encodeURIComponent(line)}`} className="group relative flex min-h-[168px] flex-col justify-between overflow-hidden rounded-[16px] border border-[#e0e7ef] bg-white p-5 transition-all hover:-translate-y-0.5 hover:border-[#bacbf2] hover:shadow-[5px_6px_0_#dce6fa]">
            <div className="flex items-start justify-between">
              <span style={{ backgroundColor: accents[line], color: ink[line] }} className="flex h-12 w-12 items-center justify-center rounded-[12px]"><Icon size={23} strokeWidth={1.8} /></span>
              <ArrowUpRight size={18} className="text-[#b3c0ce] transition-colors group-hover:text-[#3157c6]" />
            </div>
            <div>
              <h3 className="font-display text-[16px] font-bold leading-tight text-[#273c52]">{line}</h3>
              <p className="mt-1 text-[11px] text-[#98a8b8]">{busy ? 'Loading…' : line === 'Hospital' ? `${hospitalClients.length} client workspaces` : `${count} ${count === 1 ? 'procedure' : 'procedures'}`}</p>
              {!busy && line === 'Hospital' && hospitalClients.length > 0 && <div className="mt-2 space-y-0.5 border-t border-[#edf1f5] pt-2 text-[10px] leading-tight text-[#718399]">{hospitalClients.slice(0, 3).map(client => <p key={client.id} className="truncate">{client.name}</p>)}{hospitalClients.length > 3 && <p className="font-semibold text-[#3157c6]">+ {hospitalClients.length - 3} more</p>}</div>}
            </div>
          </Link>
        );
      })}
      <Link to="/portal/library" className="group flex min-h-[168px] flex-col justify-between rounded-[16px] border border-[#cbd9f6] bg-[#eaf0ff] p-5 transition-all hover:bg-[#e0e9ff]">
        <span className="flex h-12 w-12 items-center justify-center rounded-[12px] bg-white text-[#3156c6]"><Plus size={24} /></span>
        <div className="flex items-end justify-between">
          <div><h3 className="font-display text-[16px] font-bold text-[#274aae]">Explore all</h3><p className="mt-1 text-[11px] text-[#6d83bc]">Browse the full library</p></div>
          <ChevronRight size={18} className="text-[#3157c6]" />
        </div>
      </Link>
    </section>

    <div className="mb-5 flex items-end justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#3259ca]">BROWSE BY WORKFLOW</p><h2 className="mt-2 font-display text-[23px] font-bold tracking-tight text-[#1e3449]">Vertical navigation</h2><p className="mt-1.5 text-xs text-[#8291a1]">The revenue-cycle workflows that keep every client on track.</p></div></div>
    <section className="mb-12 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3" aria-label="Workflow navigation">
      {verticals.map((v, i) => {
        const count = published.filter(sop => sop.vertical === v).length;
        return (
          <Link key={v} to={`/portal/library?vertical=${encodeURIComponent(v)}`} className="group flex items-center gap-4 rounded-[14px] border border-[#e0e7ef] bg-white p-5 transition-all hover:-translate-y-0.5 hover:border-[#bacbf2] hover:shadow-[5px_6px_0_#dce6fa]">
            <span className="font-display text-[26px] font-bold leading-none text-[#aabceb]">0{i + 1}</span>
            <div className="min-w-0 flex-1">
              <h3 className="font-display text-[15px] font-bold text-[#273c52]">{v}</h3>
              <p className="mt-1 text-[11px] leading-relaxed text-[#93a3b3]">{verticalBlurb[v]}</p>
              <p className="mt-1.5 text-[11px] font-semibold text-[#5373c7]">{busy ? 'Loading…' : `${count} ${count === 1 ? 'SOP' : 'SOPs'}`}</p>
            </div>
            <ArrowRight size={18} className="shrink-0 text-[#b3c0ce] transition-colors group-hover:text-[#3157c6]" />
          </Link>
        );
      })}
    </section>

    <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
      <section className="rounded-2xl border border-[#e1e8ef] bg-white p-5 md:p-6">
        <div className="mb-5 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#3157c6]">STAY CURRENT</p><h2 className="mt-1 font-display text-xl font-bold">Recently updated SOPs</h2></div><Link to="/portal/library" className="text-xs font-bold text-[#3157c6] hover:underline">View library</Link></div>
        {published.length ? (
          <div className="divide-y divide-[#edf1f5]">
            {published.slice(0, 5).map(sop => (
              <Link key={sop.id} to={`/portal/sop/${sop.id}`} className="flex items-center gap-3 py-3.5 hover:bg-[#fbfcff]">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#eff3fb] text-[#4864ae]"><FileText size={18} /></span>
                <div className="min-w-0 flex-1"><p className="truncate text-[13px] font-bold text-[#293d51]">{sop.title}</p><p className="mt-0.5 text-[11px] text-[#93a3b3]">{clients.find(c => c.id === sop.client)?.name || 'Client'} · {sop.vertical}</p></div>
                <ChevronRight size={16} className="text-[#a4b1bf]" />
              </Link>
            ))}
          </div>
        ) : <EmptyState title="Your library starts here" description="Published SOPs will appear here once a manager adds procedures for each client." action={<Link to="/portal/library" className="portal-button">Open library</Link>} />}
      </section>
      <section className="rounded-2xl border border-[#e1e8ef] bg-white p-5 md:p-6">
        <p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#3157c6]">QUICK ACCESS</p>
        <h2 className="mt-1 font-display text-xl font-bold">Jump to a client</h2>
        <p className="mt-2 text-xs leading-relaxed text-[#8291a1]">Pick a client workspace to see its procedures across every workflow.</p>
        <div className="mt-5 space-y-2">
          {clients.length ? clients.slice(0, 6).map(c => (
            <Link key={c.id} to={`/portal/library?client=${c.id}`} className="flex items-center justify-between rounded-lg border border-[#e5ebf1] px-3 py-3 text-[12px] font-bold text-[#52677e] hover:border-[#a7bdf2] hover:text-[#3157c6]">
              <span className="truncate">{c.name}</span>
              <ArrowRight size={15} className="shrink-0 text-[#a4b1bf]" />
            </Link>
          )) : <p className="rounded-lg border border-dashed border-[#e0e7ef] px-3 py-4 text-[11px] text-[#9aa8b6]">No clients yet. A manager can add them from the library.</p>}
        </div>
        <div className="mt-5 flex items-center gap-2 rounded-lg bg-[#eff5ff] p-3 text-[11px] text-[#536e9d]"><ShieldCheck size={17} className="shrink-0 text-[#3b62ca]" /> Use the latest approved version in production.</div>
      </section>
    </div>
  </div>;
}
