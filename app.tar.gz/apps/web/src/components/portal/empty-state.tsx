import { BookOpen } from 'lucide-react';
import type { ReactNode } from 'react';
export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="flex min-h-[220px] flex-col items-center justify-center rounded-2xl border border-dashed border-[#d5e0ea] bg-white px-6 py-10 text-center"><div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#eaf0ff] text-primary"><BookOpen size={22} /></div><h3 className="font-display text-lg font-bold text-[#24384a]">{title}</h3><p className="mt-2 max-w-sm text-xs leading-relaxed text-[#8290a0]">{description}</p>{action && <div className="mt-5">{action}</div>}</div>;
}
