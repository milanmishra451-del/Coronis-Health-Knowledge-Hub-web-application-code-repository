import { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router';
import { ArrowUp, Bot, Eraser, Lightbulb, Sparkles, X } from 'lucide-react';
import { AssistantError, clearChatHistory, loadChatHistory, sendMessage } from '@/api/integrated-ai-api';
import type { ChatMessage } from '@/api/integrated-ai-api';
import pb from '@/lib/pocketbase-client';

type Draft = { role: 'user' | 'assistant'; content: string; images?: string[]; pending?: boolean };

const SUGGESTIONS = [
	'Claim billed with GZ modifier to Medicare denied as not reasonable/unnecessary — what is the latest SOP and next action?',
	'Claim denied as duplicate — when do I use modifier 76 vs 77, and when is a corrected claim vs appeal required?',
	'Medicare appeal time-limit calculation for a denial received 30 days ago — how many days remain for redetermination?',
	'Claim denied as coverage terminated — what is the AR workflow and when do I escalate to the coding team?',
];

function contextFromParams(search: URLSearchParams): string {
  const parts: string[] = [];
  const client = search.get('client');
  const vertical = search.get('vertical');
  const serviceLine = search.get('serviceLine');
  const denialType = search.get('denialType');
  if (serviceLine) parts.push(`Care setting: ${serviceLine}`);
  if (vertical) parts.push(`Workflow: ${vertical}`);
  if (denialType) parts.push(`Denial type: ${denialType}`);
  if (client) parts.push(`Client record id: ${client}`);
  return parts.length ? `Current portal context — ${parts.join(' · ')}.` : '';
}

export function SopChatbot() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Draft[]>([]);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState('');
  const [hydrated, setHydrated] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const context = useMemo(() => contextFromParams(new URLSearchParams(location.search)), [location.search]);

  useEffect(() => {
    setHydrated(true);
    loadChatHistory()
      .then((history) => setMessages(history.map(m => ({ role: m.role, content: m.content, images: m.images }))))
      .catch(() => setMessages([]));
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isStreaming) return;
    setError('');
    const contextLine = context ? `${context}\n\n` : '';
    setMessages(previous => [
      ...previous,
      { role: 'user', content: trimmed },
      { role: 'assistant', content: '', pending: true },
    ]);
    setInput('');
    setIsStreaming(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      await sendMessage({
        text: `${contextLine}${trimmed}`,
        signal: controller.signal,
        onText: chunk => setMessages(previous => {
          const next = [...previous];
          const last = next[next.length - 1];
          next[next.length - 1] = { ...last, content: last.content + chunk, pending: false };
          return next;
        }),
        onImage: url => setMessages(previous => {
          const next = [...previous];
          const last = next[next.length - 1];
          next[next.length - 1] = { ...last, images: [...(last.images ?? []), url], pending: false };
          return next;
        }),
      });
    } catch (err) {
      setMessages(previous => previous.slice(0, -1));
      if (err instanceof AssistantError) {
        if (err.status === 401) setError('Please sign in to use the SOP assistant.');
        else if (err.status === 403) setError('Please verify your email, then try again.');
        else if (err.status === 429) setError('Too many questions — please wait a minute and try again.');
        else setError(err.message);
      } else if ((err as { name?: string })?.name === 'AbortError') {
        // expected on stop / unmount
      } else {
        setError('The assistant could not answer right now. Please try again.');
      }
    } finally {
      setIsStreaming(false);
      abortRef.current = null;
    }
  };

  const stop = () => { abortRef.current?.abort(); };
  const clearAll = async () => {
    setMessages([]);
    setError('');
    try { await clearChatHistory(); } catch { /* anonymous: nothing stored */ }
  };

  const signedIn = pb.authStore.isValid;

  if (!hydrated) return null;

  return (
    <>
      {/* Launcher */}
      <button
        onClick={() => setOpen(o => !o)}
        aria-label="Open SOP assistant"
        className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-white shadow-[0_10px_30px_-6px_rgba(39,79,206,.55)] transition-transform hover:scale-105 active:scale-95"
      >
        {open ? <X size={24} /> : <Bot size={26} />}
      </button>

      {/* Panel */}
      {open && (
        <div className="fixed bottom-24 right-5 z-40 flex h-[560px] max-h-[calc(100vh-7rem)] w-[calc(100vw-2.5rem)] max-w-[400px] flex-col overflow-hidden rounded-2xl border border-[#d4e0f0] bg-white shadow-[0_24px_60px_-12px_rgba(11,28,49,.35)]">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-[#e7edf4] bg-gradient-to-br from-[#eef3ff] to-white px-4 py-3.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-white"><Sparkles size={18} /></div>
            <div className="min-w-0 flex-1">
              <p className="font-display text-[15px] font-bold leading-tight text-[#1b3046]">SOP Assistant</p>
              <p className="truncate text-[11px] text-[#7e8c9b]">AR & denial-resolution guidance</p>
            </div>
            <button onClick={clearAll} aria-label="Clear conversation" className="rounded-lg p-1.5 text-[#8291a1] hover:bg-[#eef2f8]"><Eraser size={16} /></button>
            <button onClick={() => setOpen(false)} aria-label="Close assistant" className="rounded-lg p-1.5 text-[#8291a1] hover:bg-[#eef2f8]"><X size={18} /></button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-[#f7f9fc] px-3.5 py-4">
            {messages.length === 0 && (
              <div className="px-1 pt-3">
                <div className="rounded-xl border border-[#dde7f4] bg-white p-3.5">
                  <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[.14em] text-primary"><Lightbulb size={14} /> Try asking</p>
                  <div className="mt-2.5 space-y-2">
                    {SUGGESTIONS.map(s => (
                      <button key={s} onClick={() => void send(s)} className="block w-full rounded-lg border border-[#e4ebf4] bg-[#f8faff] px-3 py-2 text-left text-[12px] leading-snug text-[#41546a] hover:border-[#a9c0ee] hover:bg-white">
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="mt-3 px-1 text-[11px] leading-relaxed text-[#94a2b0]">
                  Ask about any claim-denial scenario — modifiers, timely filing, appeal paths, or the next action to take. Do not share PHI.
                </p>
              </div>
            )}

            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${m.role === 'user' ? 'bg-primary text-white' : 'border border-[#e3eaf2] bg-white text-[#2d4257]'}`}>
                  {m.content ? <p className="whitespace-pre-wrap">{m.content}</p> : m.pending ? <span className="inline-flex gap-1"><Dot /> <Dot delay={.15} /> <Dot delay={.3} /></span> : null}
                  {m.images?.map((src, j) => <img key={j} src={src} alt="" className="mt-2 w-full rounded-lg" />)}
                </div>
              </div>
            ))}

            {error && (
              <div className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-[12px] text-red-700">{error}</div>
            )}
          </div>

          {/* Composer */}
          <div className="border-t border-[#e7edf4] bg-white p-3">
            {!signedIn && (
              <p className="mb-2 px-1 text-[10px] text-[#9aa8b6]">Open assistant · conversations are not saved while signed out.</p>
            )}
            <form onSubmit={e => { e.preventDefault(); void send(input); }} className="flex items-end gap-2">
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(input); } }}
                rows={1}
                placeholder="Describe the denial or ask for the next action..."
                className="portal-input max-h-28 min-h-[42px] flex-1 resize-none py-2.5"
              />
              {isStreaming ? (
                <button type="button" onClick={stop} className="portal-button-outline min-h-[42px] px-3">Stop</button>
              ) : (
                <button type="submit" disabled={!input.trim()} aria-label="Send" className="portal-button min-h-[42px] px-3"><ArrowUp size={17} /></button>
              )}
            </form>
          </div>
        </div>
      )}
    </>
  );
}

function Dot({ delay = 0 }: { delay?: number }) {
  return <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-[#9aa8b6]" style={{ animationDelay: `${delay}s` }} />;
}
