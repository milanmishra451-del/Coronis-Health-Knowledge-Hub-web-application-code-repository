import { Link } from 'react-router';
import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, ClipboardList, FileWarning, PhoneCall, ShieldAlert, XCircle } from 'lucide-react';
import { PageHeading } from '@/components/portal/page-heading';
import { ClientInstructions } from '@/components/portal/denial-duplicate/client-instructions';
import { ActivityTracker } from '@/components/portal/denial-duplicate/activity-tracker';

/* ---------- flowchart primitives ---------- */

function Step({ children, tone = 'process' }: { children: React.ReactNode; tone?: 'process' | 'start' | 'end' }) {
  const styles = {
    start: 'border-[#274fce] bg-[#eaf0ff] text-[#1c3a9e]',
    process: 'border-[#cdd9ea] bg-white text-[#2b4153]',
    end: 'border-[#2f9e6b] bg-[#eaf6ef] text-[#1f6e4a]',
  }[tone];
  return (
    <div className={`mx-auto max-w-[460px] rounded-xl border px-4 py-3 text-center text-[12.5px] font-semibold leading-snug shadow-[0_1px_0_#eef3f9] ${styles}`}>
      {children}
    </div>
  );
}

function Decision({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-[480px] rounded-xl border-2 border-dashed border-[#c79a3f] bg-[#fff7e8] px-4 py-3 text-center text-[12.5px] font-bold leading-snug text-[#8a5d1d]">
      {children}
    </div>
  );
}

function Connector() {
  return <div className="mx-auto h-6 w-px bg-[#c2cedb]" aria-hidden />;
}

function BranchLabel({ label, side }: { label: string; side: 'left' | 'right' }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${side === 'left' ? 'border-[#e3b7b7] bg-[#fdeeec] text-[#a8443a]' : 'border-[#b9d7c2] bg-[#eaf6ef] text-[#2f7a52]'}`}>
      {label}
    </span>
  );
}

function Branch({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-col items-center">{children}</div>;
}

/* ---------- main component ---------- */

export function DenialDuplicate() {
  return (
    <div className="mx-auto max-w-[1100px] px-5 pb-16 pt-9 md:px-9 md:pt-11">
      <Link to="/portal/library?vertical=AR" className="mb-6 inline-flex items-center gap-2 text-xs font-bold text-[#5373c7] hover:underline">
        <ArrowLeft size={15} /> Back to AR library
      </Link>

      <PageHeading
        eyebrow="AR DENIAL WORKFLOW / DUPLICATE CLAIM"
        title="Claim denied as Duplicate"
        description="The on-call script, decision tree, and action notes for working a duplicate-service denial from start to resolution."
        action={<span className="inline-flex items-center gap-2 rounded-full border border-[#f0d9b7] bg-[#fff7e8] px-3 py-1.5 text-[11px] font-bold text-[#8a5d1d]"><FileWarning size={15} /> AR · Duplicate</span>}
      />

      <ActivityTracker />

      {/* Denial Occurrence */}
      <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-7">
        <div className="mb-4 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#eaf0ff] text-[#274fce]"><AlertTriangle size={19} /></span>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">WHEN IT HAPPENS</p>
            <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">Denial occurrence</h2>
          </div>
        </div>
        <div className="space-y-3 text-[13px] leading-relaxed text-[#3d5165]">
          <p>This denial occurs when the <strong>same service on the same date of service</strong> is billed more than once.</p>
          <p>This denial also occurs if the claim is <strong>billed twice in error</strong>. In this case, the first billing claim gets processed and the second one gets denied as duplicate service.</p>
        </div>
      </section>

      <ClientInstructions />

      {/* On Call Scenario flowchart */}
      <section className="mb-10 rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-8">
        <div className="mb-6 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#eaf3fa] text-[#467aa7]"><PhoneCall size={19} /></span>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#467aa7]">CALL SCRIPT</p>
            <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">On-call scenario</h2>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <Step tone="start">Claim denied as duplicate</Step>
          <Connector />
          <Step>May I get the denial date?</Step>
          <Connector />
          <Decision>Check if CPT of your charge billed more than once on same DOS</Decision>

          {/* split into No / Yes */}
          <div className="mt-2 grid w-full gap-6 md:grid-cols-2">
            {/* NO branch */}
            <Branch>
              <BranchLabel label="No" side="left" />
              <Connector />
              <Step>What is the original status of the claim?</Step>
              <Connector />
              <Step>Follow AR scenario tool for original claim status</Step>
              <Connector />
              <Link to="/portal/library?vertical=AR" className="inline-flex items-center gap-1.5 rounded-lg border border-[#274fce] bg-[#274fce] px-4 py-2.5 text-[12px] font-bold text-white transition hover:bg-[#163ba9]">
                Click Here <ArrowRight size={14} />
              </Link>
            </Branch>

            {/* YES branch */}
            <Branch>
              <BranchLabel label="Yes" side="right" />
              <Connector />
              <Decision>Check if modifier, rendering provider and exam time on medical records are same</Decision>

              {/* nested No / Yes */}
              <div className="mt-2 grid w-full gap-6 md:grid-cols-2">
                {/* inner No */}
                <Branch>
                  <BranchLabel label="No" side="left" />
                  <Connector />
                  <Step>Can you please reprocess the claim since modifier, rendering provider or exam time on medical records are different?</Step>
                  <Connector />
                  <Decision>Rep Agrees?</Decision>

                  <div className="mt-2 grid w-full gap-6 sm:grid-cols-2">
                    {/* Rep Yes */}
                    <Branch>
                      <BranchLabel label="Yes" side="right" />
                      <Connector />
                      <Step>What is the TAT for reprocessing?</Step>
                      <Connector />
                      <Step tone="end">May I have the claim# &amp; call ref#?</Step>
                    </Branch>

                    {/* Rep No */}
                    <Branch>
                      <BranchLabel label="No" side="left" />
                      <Connector />
                      <div className="w-full space-y-6">
                        <Branch>
                          <span className="text-[11px] font-bold text-[#8a5d1d]">Rep asked to send corrected claim</span>
                          <Connector />
                          <Step>What is the corrected claim?</Step>
                          <Connector />
                          <Step tone="end">May I have the Claim# &amp; Call Ref#?</Step>
                        </Branch>
                        <Branch>
                          <span className="text-[11px] font-bold text-[#8a5d1d]">Rep asked to submit an appeal</span>
                          <Connector />
                          <Step>What is the time frame for sending an appeal? How much is the time limit?</Step>
                          <Connector />
                          <Step>What is the Fax# or Mailing address to send an appeal?</Step>
                          <Connector />
                          <Step tone="end">May I have the Claim# &amp; Call Ref#?</Step>
                        </Branch>
                      </div>
                    </Branch>
                  </div>
                </Branch>

                {/* inner Yes */}
                <Branch>
                  <BranchLabel label="Yes" side="right" />
                  <Connector />
                  <Step tone="end">May I have the claim# &amp; call ref#?</Step>
                  <Connector />
                  <div className="mx-auto max-w-[460px] rounded-xl border border-[#e3b7b7] bg-[#fdeeec] px-4 py-3 text-center text-[12px] font-bold text-[#a8443a]">
                    The charge should be voided
                  </div>
                </Branch>
              </div>
            </Branch>
          </div>
        </div>
      </section>

      {/* Important Notes & Actions */}
      <section className="rounded-[15px] border border-[#e0e7ef] bg-white p-6 md:p-7">
        <div className="mb-5 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#fdeeec] text-[#a8443a]"><ShieldAlert size={19} /></span>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#a8443a]">TAKE ACTION</p>
            <h2 className="mt-0.5 font-display text-[18px] font-bold text-[#283d52]">Important notes &amp; actions</h2>
          </div>
        </div>

        <p className="mb-5 rounded-lg bg-[#f7f9fc] px-4 py-3 text-[12px] leading-relaxed text-[#5d7187]">
          Please take action as per your process update. The actions below can differ from your process update.
        </p>

        <ul className="space-y-3">
          {[
            { icon: XCircle, tone: 'red', text: 'If the same CPT is not billed more than once on the same DOS, ask for the original claim status and follow the AR Scenario based on the denial reason.' },
            { icon: CheckCircle2, tone: 'green', text: 'If the same CPT is billed more than once on the same DOS and modifier, rendering provider & exam time on the medical records are not same and the rep agrees to reprocess the claim, set the follow-up for the TAT provided by the rep.' },
            { icon: ClipboardList, tone: 'blue', text: 'If the same CPT is billed more than once on the same DOS and modifier, rendering provider & exam time on the medical records are not same and the rep denies reprocessing and asks to send a corrected claim, update the correct modifier and submit the corrected claim by updating the correct billing code "7" along with the claim number.' },
            { icon: ClipboardList, tone: 'blue', text: 'When rendering providers on the charges are different, add a 77 modifier and resubmit the corrected claim.' },
            { icon: ClipboardList, tone: 'blue', text: 'When rendering providers on the charges are the same but the exam times are different, add a 76 modifier and resubmit the corrected claim.' },
            { icon: ShieldAlert, tone: 'amber', text: 'After sending the corrected claim, if the claim is again denied for the same reason and the insurance rep denies reprocessing, send an appeal to insurance.' },
            { icon: ShieldAlert, tone: 'amber', text: 'When modifiers on the charges are different and the rep denies reprocessing the claim, send an appeal to insurance.' },
            { icon: AlertTriangle, tone: 'amber', text: 'Medicare does not accept corrected claims — send a fresh claim to Medicare.' },
            { icon: ShieldAlert, tone: 'amber', text: 'If the same CPT is billed more than once on the same DOS and modifier, rendering provider & exam time on the medical records are not same and the rep denies reprocessing and asks to send an appeal, send an appeal to insurance.' },
            { icon: ClipboardList, tone: 'blue', text: 'When sending an appeal, calculate the time limit from the denial date. If it is not crossed, send the document; otherwise write off the claim if the time limit is crossed.' },
            { icon: AlertTriangle, tone: 'amber', text: 'Sometimes the client wants the document sent even if the time limit is crossed — work accordingly.' },
            { icon: XCircle, tone: 'red', text: 'If the same CPT is billed more than once on the same DOS and modifier, rendering provider & exam time on the medical records are the same, the charge should be voided.' },
            { icon: AlertTriangle, tone: 'amber', text: 'Sometimes the client wants coding-team clarification to determine whether these are duplicate charges or not — work as per client instructions.' },
          ].map((item, i) => {
            const toneMap: Record<string, string> = {
              red: 'bg-[#fdeeec] text-[#a8443a]',
              green: 'bg-[#eaf6ef] text-[#2f7a52]',
              blue: 'bg-[#eaf0ff] text-[#274fce]',
              amber: 'bg-[#fff7e8] text-[#8a5d1d]',
            };
            const Icon = item.icon;
            return (
              <li key={i} className="flex gap-3 rounded-xl border border-[#edf1f5] bg-[#fbfcfe] p-4">
                <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${toneMap[item.tone]}`}><Icon size={17} /></span>
                <p className="text-[12.5px] leading-relaxed text-[#3d5165]">{item.text}</p>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
