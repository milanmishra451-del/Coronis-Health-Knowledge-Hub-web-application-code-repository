import pb from '@/lib/pocketbase-client';

export const serviceLines = ['Hospital', 'Physician', 'FQHC', 'RHC', 'Behavioral Health', 'EMS', 'Lab & Path'] as const;
export const verticals = ['Charge Entry', 'Payment Posting', 'AR', 'Authorization', 'Eligibility', 'Coding'] as const;
export type Role = 'employee' | 'trainer' | 'manager';
export type PortalClient = { id: string; name: string; code: string; description: string; serviceLine?: string };
export type Sop = { id: string; title: string; summary: string; client: string; vertical: string; serviceLine: string; denialType: string; scenario: string; status: string; created: string; updated: string; owner: string };
export type Version = { id: string; sop: string; version: string; changeNote: string; document: string; created: string; uploadedBy: string };
export type QuizQuestion = { prompt: string; options: string[]; correctIndex: number; explanation?: string };
export type Quiz = { id: string; sop: string; title: string; caseStudy: string; questions: QuizQuestion[] };
export type Activity = { id: string; member: string; eventType: string; sop: string; seconds: number; detail: string; created: string };
export type Attempt = { id: string; member: string; quiz: string; score: number; points: number; created: string };
export type Resource = { id: string; title: string; category: string; url: string; phone: string; notes: string };
export type Staff = { id: string; name: string; email: string; role: Role; department: string; clients: string[] };

export const roleLabel: Record<Role, string> = { employee: 'Employee', trainer: 'Trainer', manager: 'Manager' };
export function currentRole(): Role { return (pb.authStore.record?.role as Role) || 'employee'; }
export function canPublish() { return currentRole() === 'manager'; }
export function canCreate() { return currentRole() === 'manager' || currentRole() === 'trainer'; }
export function logActivity(action: string, detail = '', sop = '', seconds = 0) {
  const user = pb.authStore.record?.id;
  if (!user) return Promise.resolve();
  return pb.collection('portal_activity').create({ member: user, eventType: action, detail: detail.slice(0, 300), sop: sop || undefined, seconds }, { requestKey: null }).then(() => undefined);
}
export function friendlyError(error: unknown) {
  if (error && typeof error === 'object' && 'response' in error) {
    const response = (error as { response?: { message?: string; data?: Record<string, { message?: string }> } }).response;
    const field = response?.data && Object.values(response.data)[0]?.message;
    return field || response?.message || 'The request could not be completed. Check your access and try again.';
  }
  return error instanceof Error ? error.message : 'The request could not be completed. Please try again.';
}
