import type { Route } from './+types/portal-denial-duplicate';
import { seo } from '@/lib/seo';
import { DenialDuplicate } from '@/components/portal/denial-duplicate';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Claim Denied as Duplicate — AR Workflow | Coronis Health',
    description: 'On-call script, decision tree, and action notes for working a duplicate-service denial from start to resolution.',
  });
}

export default function PortalDenialDuplicate() {
  return <DenialDuplicate />;
}
