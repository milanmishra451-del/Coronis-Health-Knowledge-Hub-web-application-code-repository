import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { PublicLanding } from '@/components/home/public-landing';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Coronis Health | SOP Knowledge Hub', description: 'The secure internal knowledge hub for Coronis Health SOPs, workflows, and team learning.' }); }
export default function HomePage() { return <PublicLanding />; }
