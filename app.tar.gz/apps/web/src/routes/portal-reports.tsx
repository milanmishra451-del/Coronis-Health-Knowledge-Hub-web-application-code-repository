import type { Route } from './+types/portal-reports';
import { seo } from '@/lib/seo';
import { Reports } from '@/components/portal/reports';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Reports & Insights | Coronis Health', description: 'Monitor SOP usage, assessment completion, reading time, and department learning progress.' }); }
export default function PortalReports() { return <Reports />; }
