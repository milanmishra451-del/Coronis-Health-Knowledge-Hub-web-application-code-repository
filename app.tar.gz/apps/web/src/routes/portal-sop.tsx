import type { Route } from './+types/portal-sop';
import { seo } from '@/lib/seo';
import { SopDetail } from '@/components/portal/sop-detail';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Procedure | Coronis Health SOP Portal', description: 'View controlled SOP versions, linked quizzes, and learning activity.' }); }
export default function PortalSop() { return <SopDetail />; }
