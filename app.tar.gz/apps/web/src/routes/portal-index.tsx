import type { Route } from './+types/portal-index';
import { seo } from '@/lib/seo';
import { Overview } from '@/components/portal/overview';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Overview | Coronis Health SOP Portal', description: 'Your SOP workspace, care verticals, learning points, and recently updated procedures.' }); }
export default function PortalIndex() { return <Overview />; }
