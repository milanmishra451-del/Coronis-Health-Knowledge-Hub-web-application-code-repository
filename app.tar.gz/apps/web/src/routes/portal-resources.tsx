import type { Route } from './+types/portal-resources';
import { seo } from '@/lib/seo';
import { Resources } from '@/components/portal/resources';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Resource Center | Coronis Health', description: 'AR scenarios, denial management, RCM workflows, Medicare references, and payer resources.' }); }
export default function PortalResources() { return <Resources />; }
