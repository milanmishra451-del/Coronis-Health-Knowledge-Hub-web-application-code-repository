import type { Route } from './+types/portal-team';
import { seo } from '@/lib/seo';
import { Team } from '@/components/portal/team';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Team & Access | Coronis Health', description: 'Manager workspace for role-based team and client access.' }); }
export default function PortalTeam() { return <Team />; }
