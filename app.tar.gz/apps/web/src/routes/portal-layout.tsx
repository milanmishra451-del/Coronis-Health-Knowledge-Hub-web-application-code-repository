import type { Route } from './+types/portal-layout';
import { seo } from '@/lib/seo';
import { PortalShell } from '@/components/portal/portal-shell';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'Workspace | Coronis Health SOP Portal', description: 'Secure Coronis Health SOP and learning workspace.' }); }
export default function PortalLayout() { return <PortalShell />; }
