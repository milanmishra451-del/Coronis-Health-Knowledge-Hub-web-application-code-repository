import { redirect } from 'react-router';
import type { Route } from './+types/login';

// The standalone login page was removed; redirect any stale link or bookmark
// to the public landing page until authentication is re-introduced.
export function loader() {
	throw redirect('/');
}

export default function LoginRedirect() {
	return null;
}
