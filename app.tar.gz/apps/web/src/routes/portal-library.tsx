import type { Route } from './+types/portal-library';
import { seo } from '@/lib/seo';
import { Library } from '@/components/portal/library';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, { title: 'SOP Library | Coronis Health', description: 'Search approved SOPs by client, workflow, care setting, denial type, and AR scenario.' }); }
export default function PortalLibrary() { return <Library />; }
