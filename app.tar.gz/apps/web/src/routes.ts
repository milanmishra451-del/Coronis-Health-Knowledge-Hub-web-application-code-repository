import { type RouteConfig, index, route } from '@react-router/dev/routes';

export default [
	index('routes/home.tsx'),
	route('login', 'routes/login.tsx'),
	route('portal', 'routes/portal-layout.tsx', [
		index('routes/portal-index.tsx'),
		route('library', 'routes/portal-library.tsx'),
		route('sop/:sopId', 'routes/portal-sop.tsx'),
		route('denial/duplicate', 'routes/portal-denial-duplicate.tsx'),
		route('resources', 'routes/portal-resources.tsx'),
		route('reports', 'routes/portal-reports.tsx'),
		route('team', 'routes/portal-team.tsx'),
	]),
	route('sitemap.xml', 'routes/sitemap.xml.ts'),
	route('robots.txt', 'routes/robots.txt.ts'),
	route('api/health', 'routes/api.health.ts'),
	route('api/integrated-ai/stream', 'routes/api.integrated-ai.stream.ts'),
	route('api/*', 'routes/api.$.ts'),
] satisfies RouteConfig;
